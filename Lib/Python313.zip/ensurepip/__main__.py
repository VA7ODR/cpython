import ensurepip
import sys

if __name__ == "__main__":
    sys.exit(ensurepip._main())
